
<?php $__env->startSection('title'); ?>
Dashboard || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="page-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->username); ?></span>
                                    <?php endif; ?>
                    </h3>
                    <div class="d-inline-block align-items-center">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">Welcome back, <?php echo e(Auth::user()->username); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <h4 align="right">Total Balance: ₦<?php echo e($totalbalance); ?></h4>
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xl-12 col-12">
                    <div class="row">
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total Deposit</h5>
                                            <h2 class="font-weight-500 mb-0">₦<?php echo e($totaldeposit); ?></h2>
                                        </div>
                                        <div class="text-primary" style="padding: 35px;">
                                            <h1><span class="ti ti-import"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Task Earnings</h5>
                                            <h2 class="font-weight-500 mb-0">₦<?php echo e($taskearning); ?></h2>
                                        </div>
                                        <div class="text-info" style="padding: 35px;">
                                            <h1><span class="ti ti-wallet"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total withdrawal</h5>
                                            <h2 class="font-weight-500 mb-0">₦<?php echo e($totalwithdrawal); ?></h2>
                                        </div>
                                        <div class="text-danger" style="padding: 35px;">
                                            <h1><span class="ti ti-export"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total Spents</h5>
                                            <h2 class="font-weight-500 mb-0">₦<?php echo e($totalspent); ?></h2>
                                        </div>
                                        <div class="text-warning" style="padding: 35px;">
                                            <h1><span class="ti ti-new-window"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Referral Earnings</h5>
                                            <h2 class="font-weight-500 mb-0"><?php echo e($referralearnings); ?></h2>
                                        </div>
                                        <div class="text-secondary" style="padding: 35px;">
                                            <h1><span class="ti ti-wallet"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total Referal</h5>
                                            <h2 class="font-weight-500 mb-0"><?php echo e($referrals); ?></h2>
                                        </div>
                                        <div class="text-success" style="padding: 35px;">
                                            <h1><span class="glyphicon glyphicon-share"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total advert</h5>
                                            <h2 class="font-weight-500 mb-0"><?php echo e($orders); ?></h2>
                                        </div>
                                        <div class="text-warning" style="padding: 35px;">
                                            <h1><span class="glyphicon glyphicon-list"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total Members</h5>
                                            <h2 class="font-weight-500 mb-0"><?php echo e($users); ?></h2>
                                        </div>
                                        <div class="text-primary" style="padding: 35px;">
                                            <h1><span class="fa fa-users"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="box">
                                <div class="box-body py-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="text-fade">Total Product</h5>
                                            <h2 class="font-weight-500 mb-0"><?php echo e($products); ?></h2>
                                        </div>
                                        <div class="text-secondary" style="padding: 35px;">
                                            <h1><span class="fa fa-shopping-basket"></span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>