
<?php $__env->startSection('title'); ?>
Topup Request || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(Auth::user()->activated == 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="padding: 20px;border-radius:7px;">
                    Account not Activated. to activate your account you must activate your account by paying a one-time membership fee of <strong>₦3,000</strong>. Click <a href="<?php echo e(url('/user/activate-account')); ?>">Here</a> to become a member today.
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <br>
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->profile->first()->fname); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->profile->first()->fname); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->profile->first()->fname); ?></span>
                                    <?php endif; ?>

                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                </div>
            </div>
        </div>
</section>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="account-card">
                    <h3 class="account-title">Airtime/Data Topup Request</h3>
                    <p>Please Enter Airtime/Data Topup Information. Fund will be deducted from Wallet Balance</p>
                    <br>
                    <form method="post" action="<?php echo e(url('/user/topup')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6" style="padding-top: 18px;">
                                <label>Type<span class="text-danger">*</span></label>
                                <select class="form-control" name="type">
                                    <option selected disabled>Select Topup Type</option>
                                    <option value="Airtime">Airtime</option>
                                    <option value="Data">Data</option>
                                </select>
                            </div>
                            <div class="col-md-6" style="padding-top: 18px;">
                                <label>Amount (₦)<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="amount" placeholder="₦0.00">
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-6" style="padding-top: 18px;">
                                <label>network<span class="text-danger">*</span></label>
                                <select class="form-control" name="network">
                                    <option selected disabled>Select Network</option>
                                    <option value="MTN">MTN</option>
                                    <option value="GLO">GLO</option>
                                    <option value="AIRTEL">AIRTEL</option>
                                    <option value="9MOBILE">9MOBILE</option>
                                </select>
                            </div>
                            <div class="col-md-6" style="padding-top: 18px;">
                                <label>Phone Number<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="phone" placeholder="081XXXXXXXXX">
                            </div><br class="mobileshow">
                        </div><br><br>
                        <div align="center">
                            <button type="submit" class="btn btn-inline">Place Topup Request</button>
                        </div>
                    </form><br>
                    <p style="font-size: 13px;">Please note that Topup Request takes between 24-48hrs to get to your Submitted Phone Number</p>
                </div>
                <div class="account-card">
                    <h3 class="account-title">My Airtime/Data Topup History </h3>
                    <div class="orderlist">
                        <div class="table-scroll table-responsive">
                            <table class="table table-stripped table-list">
                                <thead>
                                    <tr style="background-color: #5f04f6;">
                                        <th class="text-white" scope="col">#</th>
                                        <th class="text-white">Date</th>
                                        <th class="text-white">Amount</th>
                                        <th class="text-white">Type</th>
                                        <th class="text-white">Phone</th>
                                        <th class="text-white">Network</th>
                                        <th class="text-white">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $topup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <h6><?php echo e($number); ?></h6>
                                        </td>
                                        <td><?php echo e($top->created_at->format('d M Y ')); ?></td>
                                        <td>₦<?php echo e(number_format($top->amount, 0, '.', ', ')); ?></td>
                                        <td><?php echo e($top->type); ?></td>
                                        <td><?php echo e($top->phone); ?></td>
                                        <td><?php echo e($top->network); ?></td>
                                        <td>
                                            <?php if($top->status == 0): ?>
                                            <span class="badge bg-danger">Pending</span>
                                            <?php elseif($top->status == 1): ?>
                                            <span class="badge bg-success">Paid</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php $number++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <section class="inner-section wallet-part">
                    <div class="container">
                        <div class="account-card"><br>
                            <div class="account-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div>
                                            <h3 class="text-center"><strong>Data Plan Price List</strong></h3>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <?php $__currentLoopData = $topupplan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row row-cols-1 row-cols-md-1 row-cols-lg-1 row-cols-xl-1">
                                    <div class="col">
                                        &nbsp; &nbsp;&nbsp;
                                        <?php if($plan->network == 1): ?>
                                        <img src="../assetsuser/images/mtn.jpg" width="50px" height="50px">
                                        <?php elseif($plan->network == 2): ?>
                                        <img src="../assetsuser/images/glo.jpg" width="50px" height="40px">
                                        <?php elseif($plan->network == 4): ?>
                                        <img src="../assetsuser/images/airtel.png" width="50px" height="40px">
                                        <?php elseif($plan->network == 3): ?>
                                        <img src="../assetsuser/images/9mobile.png" width="40px" height="50px">
                                        <?php endif; ?>
                                        &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                        <a href="#" style="font-size: 20px;text-align:left;"><?php echo e($plan->unit); ?> - ₦<?php echo e(number_format($plan->price, 0, '.', ', ')); ?></a>
                                    </div>
                                </div>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                </section>
            </div>
        </div>
    </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/topup.blade.php ENDPATH**/ ?>