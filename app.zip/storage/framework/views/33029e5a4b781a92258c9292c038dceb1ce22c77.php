
<?php $__env->startSection('title'); ?>
Place Withdrawal || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(Auth::user()->activated == 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="padding: 20px;border-radius:7px;">
                    Account not Activated. to activate your account you must activate your account by paying a one-time membership fee of <strong>₦3,000</strong>. Click <a href="<?php echo e(url('/user/activate-account')); ?>">Here</a> to become a member today.
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <br>
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->profile->first()->fname); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->profile->first()->fname); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->profile->first()->fname); ?></span>
                                    <?php endif; ?>

                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                </div>
            </div>
        </div>
</section>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="account-card">
                    <h3 class="account-title">Place Withdrawal</h3>
                    <p>Please Enter amount you want to withdraw from your wallet</p>
                    <br><br>
                    <form method="post" action="<?php echo e(url('/user/withdraw')); ?>" class="wallet-form">
                        <?php echo csrf_field(); ?>
                        <div class="row row-cols-2 row-cols-md-2 row-cols-lg-2 row-cols-xl-2">
                            <div class="col">
                                <label>Amount (₦)<span class="text-danger">*</span></label>
                                <input type="text" name="amount" placeholder="₦0.00">
                            </div>
                            <div class="col">
                                <button type="submit" style="margin-top: 25px;">Withdraw</button>
                            </div>
                        </div>
                    </form><br>
                    <p style="font-size: 13px;">Please note that withdrawal takes between 24-48hrs to get credited into your registered bank account</p>
                </div>
                <div class="account-card">
                    <h3 class="account-title">My Withdrawal History </h3>
                    <div class="orderlist">
                        <div class="table-scroll table-responsive">
                            <table class="table table-stripped table-list">
                                <thead>
                                    <tr style="background-color: #5f04f6;">
                                        <th class="text-white" scope="col">#</th>
                                        <th class="text-white">Date</th>
                                        <th class="text-white">Amount</th>
                                        <th class="text-white">Status</th>
                                        <th class="text-white">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <h6><?php echo e($number); ?></h6>
                                        </td>
                                        <td><?php echo e($transact->created_at->format('d M Y ')); ?></td>
                                        <td>₦<?php echo e(number_format($transact->amount, 0, '.', ', ')); ?></td>
                                        <td>
                                            <?php if($transact->status == 0): ?>
                                            <span class="badge bg-danger">Awaiting Payment</span>
                                            <?php elseif($transact->status == 1): ?>
                                            <span class="badge bg-success">Paid</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-success" style="padding: 3px 6px 3px 6px;text-transform:capitalize;font-size:12px;">Pay Now</button>
                                            <button class="btn btn-danger" style="padding: 3px 6px 3px 6px;text-transform:capitalize;font-size:12px;">Delete</button>
                                            
                                        </td>
                                    </tr>
                                    <?php $number++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <section class="inner-section wallet-part">
                    <div class="container desktopshow">
                        <div class="account-card"><br>
                            <div class="account-content">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div>
                                            <a href="# "><img src="../assetsuser/images/user.png" width="55px" height="50px" alt="user "></a>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <h6><?php echo e(Auth::user()->profile->first()->fname); ?> <?php echo e(Auth::user()->profile->first()->lname); ?> </h6>
                                        <span style="font-size: 13px;" class="muted">@ <?php echo e(Auth::user()->username); ?></span>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="../assetsuser/images/earn.png" width="50px" height="50px">
                                    </div>
                                    <div class="col-md-9">
                                        <a href="<?php echo e(url('/user/advertise')); ?>" style="font-size: 11px;">Earn daily by posting adverts of businesses and performing social tasks on your social media accounts</a>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="../assetsuser/images/social.jpg" width="50px" height="50px">
                                    </div>
                                    <div class="col-md-9">
                                        <a href="<?php echo e(url('/user/advertise')); ?>" style="font-size: 11px;">Get people to repost your adverts and perform social tasks for you on their social media pages.</a>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="../assetsuser/images/networks.png" width="50px" height="50px">
                                    </div>
                                    <div class="col-md-9">
                                        <a href="#" style="font-size: 11px;">Buy Airtime and Data and enjoy up to 3% - 10% Discount across all networks.</a>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="../assetsuser/images/market.png" width="50px" height="50px">
                                    </div>
                                    <div class="col-md-9">
                                        <a href="<?php echo e(url('/user/sell')); ?>" style="font-size: 11px;">Take advantage of our huge traffic and advertise anything on the Miscochat Market.</a>
                                    </div>
                                </div>
                                <hr>
                            </div>
                        </div>
                </section>
            </div>
        </div>
    </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/withdrawal.blade.php ENDPATH**/ ?>