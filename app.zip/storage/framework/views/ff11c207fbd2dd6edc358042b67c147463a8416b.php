
<?php $__env->startSection('title'); ?>
Topup Plan || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="page-title">Top up Plan</h3>
                    <div class="d-inline-block align-items-center">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="ti ti-home"></i></a></li>
                                <li class="breadcrumb-item" aria-current="page">Mobile Topup</li>
                                <li class="breadcrumb-item active" aria-current="page">Plan</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div align="right">
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#exampleModalCenter">Create New Plan</button>
                </div>
                <!-- modal content -->
                <div class="modal fade" id="exampleModalCenter">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myModalLabel">Create New Mobile Topup Plan</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            </div>
                            <form method="POST" action="<?php echo e(url('admin/save-mobile-topup-plan')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="control-label">Network Type:</label>
                                        <select class="form-control" name="network">
                                            <option selected disabled>Select Network</option>
                                            <option value="MTN">MTN</option>
                                            <option value="GLO">GLO</option>
                                            <option value="9MOBILE">9MOBILE</option>
                                            <option value="AIRTEL">AIRTEL</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Topup Unit:</label>
                                        <input type="text" class="form-control" name="unit" placeholder="1gb" value="<?php echo e(Request::old('unit')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Price:</label>
                                        <input type="text" class="form-control" name="price" placeholder="250" value="<?php echo e(Request::old('price')); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Add Topup Plan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.modal -->
            </div>
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="box">
                        <div class="box-body">
                            <div class="table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Network</th>
                                            <th>Unit</th>
                                            <th>Price</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $topupplan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h6><?php echo e($number); ?></h6>
                                            </td>

                                            <td><?php echo e($plan->network); ?></td>
                                            <td><?php echo e($plan->unit); ?></td>
                                            <td><?php echo e($plan->price); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#modal-edit<?php echo e($plan->id); ?>"> Edit Plan </button>
                                                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-default<?php echo e($plan->id); ?>"> Delete </button>
                                                <!-- modal Area -->
                                                <div class="modal fade" id="modal-default<?php echo e($plan->id); ?>">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Delete Mobile Topup Plan</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <h4><strong>Confirm Deletion</strong></h4>
                                                                <p>Are you sure you want to Delete <strong> <?php echo e($plan->network); ?> <?php echo e($plan->unit); ?> </strong></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?php echo e(route('deletetopupplan',$plan->id)); ?>" class="btn btn-primary float-right">Delete Topup Plan</a>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>
                                                <!-- /.modal -->
                                                <!-- modal Area -->
                                                <div class="modal fade" id="modal-edit<?php echo e($plan->id); ?>">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Edit Mobile Topup Plan </h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span></button>
                                                            </div>
                                                            <form method="post" action="<?php echo e(route('updatetopupplan',$plan->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label class="control-label">Network Type:</label>
                                                                        <select class="form-control" name="network">
                                                                            <option value="<?php echo e($plan->network); ?>" selected><?php echo e($plan->network); ?></option>
                                                                            <option disabled>Select Another Network</option>
                                                                            <option value="MTN">MTN</option>
                                                                            <option value="GLO">GLO</option>
                                                                            <option value="9MOBILE">9MOBILE</option>
                                                                            <option value="AIRTEL">AIRTEL</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="control-label">Topup Unit:</label>
                                                                        <input type="text" class="form-control" name="unit" placeholder="1gb" value="<?php echo e($plan->unit); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="control-label">Price:</label>
                                                                        <input type="text" class="form-control" name="price" placeholder="250" value="<?php echo e($plan->price); ?>">
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                    <button class="btn btn-primary float-right" type="submit">Update Topup Plan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>
                                                <!-- /.modal -->
                                            </td>
                                        </tr>
                                        <?php $number++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/admin/topup_plan.blade.php ENDPATH**/ ?>