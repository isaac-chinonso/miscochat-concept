
<?php $__env->startSection('title'); ?>
Pending Withdrawal History || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="page-title">Pending Withdrawal</h3>
                    <div class="d-inline-block align-items-center">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="ti ti-home"></i></a></li>
                                <li class="breadcrumb-item" aria-current="page">Withdrawal</li>
                                <li class="breadcrumb-item active" aria-current="page">Pending Withdrawal</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="box">
                        <div class="box-body">
                            <div class="table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Bank </th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $pendingwithdrawal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h6><?php echo e($number); ?></h6>
                                            </td>

                                            <td><?php echo e($transact->user->username); ?></td>
                                            <td><?php echo e($transact->created_at->format('d M Y ')); ?></td>
                                            <td>₦<?php echo e(number_format($transact->amount,0,'.',',')); ?></td>
                                            <td><?php echo e($transact->type); ?></td>
                                            <td>
                                                <?php if($transact->status == 0): ?>
                                                <span class="badge bg-danger">Pending</span>
                                                <?php elseif($transact->status == 1): ?>
                                                <span class="badge bg-success">Paid</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $bankdetails->where('user_id', $transact->user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($bank->bank_name); ?> <?php echo e($bank->account_num); ?><br> <?php echo e($bank->account_name); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#activate<?php echo e($transact->id); ?>"> Approve </button>
                                                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#decline<?php echo e($transact->id); ?>"> Decline </button>
                                            </td>
                                            <!--Approve modal content -->
                                            <div id="activate<?php echo e($transact->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">Approve Withdrawal</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h4><strong>Mark Withdrawal as Paid</strong></h4>
                                                            <p>Are you sure you want to Mark Withdrawal of <strong>₦<?php echo e(number_format($transact->amount,0,'.',',')); ?></strong> from <strong><?php echo e($transact->user->username); ?></strong> as Paid</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                            <a href="<?php echo e(route('adminapprovewithdrawal',$transact->id)); ?>" class="btn btn-success btn-sm waves-effect waves-light">Approve Withdrawal</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal -->
                                            <!--Decline modal content -->
                                            <div id="decline<?php echo e($transact->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">Decline Withdrawal</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h4><strong>Decline  Withdrawal</strong></h4>
                                                            <p>Are you sure you want to Decline Withdrawal of <strong>₦<?php echo e(number_format($transact->amount, 0,'.',',')); ?></strong> from <strong><?php echo e($transact->user->username); ?></strong></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                            <a href="<?php echo e(route('admindeclinewithdrawal',$transact->id)); ?>" class="btn btn-danger btn-sm waves-effect waves-light">Decline Withdrawal</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal -->
                                        </tr>
                                        <?php $number++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/admin/pendingwithdrawal.blade.php ENDPATH**/ ?>