<?php if(Session::has('warning_message')): ?>
<div class="alert alert-warning alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Oops!</strong> <?php echo e(Session::get('warning_message')); ?>

</div>
<?php endif; ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/include/warning.blade.php ENDPATH**/ ?>