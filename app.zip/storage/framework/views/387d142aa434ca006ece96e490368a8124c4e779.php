
<?php $__env->startSection('title'); ?>
Marketplace || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section shop-part">
    <div class="container">
        <div class="row ">
            <div class="col-lg-12 ">
                <div class="section-heading ">
                    <h2>Miscochat Marketplace</h2>
                </div>
            </div>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-5">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="product-card">
                    <div class="product-media">
                        <a class="product-image" href="#"><img src="../product/<?php echo e($prod->image); ?>" height="170px" alt="product"></a>
                    </div>
                    <div class="product-content">
                        <h6 class="product-name "><a href="#"><?php echo e($prod->name); ?></a></h6>
                        <h6 class="product-price"><span>₦<?php echo e(number_format($prod->price, 0, '.', ', ')); ?></span></h6>
                        <a href="<?php echo e(route('userproductdetails', $prod->slug)); ?>" class="btn btn-outline" style="padding:7px 8px 7px 8px;font-size:12px;"><i class="fas fa-eye"></i>View Product</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="bottom-paginate">
                    <ul class="pagination">
                        <li class="page-item "><a class="page-link " href="# "><i class="fas fa-long-arrow-alt-left "></i></a></li>
                        <li class="page-item "><a class="page-link active " href="# "><?php echo e($product->links()); ?></a></li>
                        <li class="page-item "><a class="page-link " href="# "><i class="fas fa-long-arrow-alt-right "></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/market.blade.php ENDPATH**/ ?>