
<?php $__env->startSection('title'); ?>
Dashboard || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php $__currentLoopData = $noticeboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert" style="padding: 20px;border-radius:7px;">
                <h5><?php echo e($notice->title); ?></h5>    
                <?php echo e($notice->notice_text); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-12">
                <?php if(Auth::user()->activated == 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="padding: 20px;border-radius:7px;">
                    Account not Activated. to activate your account you must activate your account by paying a one-time membership fee of <strong>₦3,000</strong>. Click <a href="<?php echo e(url('/user/activate-account')); ?>">Here</a> to become a member today.
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->username); ?></span>
                                    <?php endif; ?>
                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                    <div class="row row-cols-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-4">
                        <div class="col">
                            <div class="wallet-card" style="background-color: #6864ed;">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h2><i class="fa fa-list text-white"></i></h2>
                                    </div>
                                    <div class="col-md-8">
                                        <p class="text-white">Task Earnings</p>
                                        <h3 class="text-white">₦<?php echo e(number_format($taskearning, 0, '.', ', ')); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="wallet-card" style="background-color: #08b445;">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h2><i class="fa fa-wallet text-white"></i></h2>
                                    </div>
                                    <div class="col-md-8">
                                        <p class="text-white">Total Spent</p>
                                        <h3 class="text-white">₦<?php echo e(number_format($totalspent, 0, '.', ', ')); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="wallet-card" style="background-color: #6ea6fa;">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h2><i class="fa fa-share-square text-white"></i></h2>
                                    </div>
                                    <div class="col-md-8">
                                        <p class="text-white">Total Referral</p>
                                        <h3 class="text-white"><?php echo e($referrals); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="wallet-card" style="background-color: #f91934;">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h2><i class="fa fa-tag text-white"></i></h2>
                                    </div>
                                    <div class="col-md-8">
                                        <p class="text-white">Referral Earnings</p>
                                        <h3 class="text-white">₦<?php echo e($referralearning); ?></h3>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="banner-btn" align="center">
                <h4 style="text-align:center;"><strong>Your Refferal ID: <?php echo e(Auth::user()->username); ?> </strong> </h4> <br>
                <a class="btn btn-inline" href="<?php echo e(url('/user/deposit-wallet')); ?>"><i class="fas fa-credit-card"></i><span>FUND</span></a>
                <a class="btn btn-outline" href="<?php echo e(url('/user/place-withdrawal')); ?>"><i class="fa fa-wallet"></i><span>WITHDRAW</span></a>
            </div><br><br>
        </div>
    </div>
</div>
<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="account-card">
                    <h3 class="account-title">My Tasks </h3>
                    <div class="orderlist">
                        <div class="table-scroll table-responsive">
                            <table class="table table-stripped table-list">
                                <thead>
                                    <tr style="background-color: #5f04f6;">
                                        <th class="text-white" scope="col">#</th>
                                        <th class="text-white">platform</th>
                                        <th class="text-white">Amount to Earn</th>
                                        <th class="text-white">Description</th>
                                        <th class="text-white">Date</th>
                                        <th class="text-white">Accepted Users</th>
                                        <th class="text-white">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $count = 0; ?>
                                    <?php $__currentLoopData = $adverttaskscount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adverttask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($adverttask->order_id == $task->id): ?>
                                    <?php $count++; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($count >= $task->quantity): ?>
                                    <?php else: ?>
                                    <tr>
                                        <td>
                                            <h6><?php echo e($number); ?></h6>
                                        </td>
                                        <td>
                                            <h6><?php echo e($task->platform); ?></h6>
                                        </td>
                                        <th><?php echo e($task->userearn); ?></th>
                                        <td><?php echo e($task->caption); ?></td>
                                        <td>
                                            <h6><?php echo e($task->created_at->format('d M Y ')); ?></h6>
                                        </td>
                                        <td>
                                            <?php $count = 0; ?>
                                            <?php $__currentLoopData = $adverttaskscount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adverttask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($adverttask->order_id == $task->id): ?>
                                            <?php $count++; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($count); ?> / <?php echo e($task->quantity); ?>

                                        </td>
                                        <td>
                                            <?php if($task->user_id == Auth::user()->id): ?>

                                            <?php else: ?>
                                            <button class="btn btn-success" data-toggle="modal" data-target="#responsive-modal2<?php echo e($task->id); ?>" style="padding: 3px 6px 3px 6px;text-transform:capitalize;font-size:12px;">Accept</button>
                                            <?php endif; ?>
                                            <!-- Accept Task modal content -->
                                            <div id="responsive-modal2<?php echo e($task->id); ?>" class="modal">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">Accept Task</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h4><strong>Confirm </strong></h4>
                                                            <p>Are you sure you want to Accept <?php echo e($task->platform); ?> Task</p>
                                                        </div>
                                                        <form method="post" action="<?php echo e(route('accepttask',$task->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="order_id" value="<?php echo e($task->id); ?>">
                                                            <input type="hidden" name="buyer_id" value="<?php echo e($task->user_id); ?>">
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-default" style="padding: 7px 8px 7px 8px;font-size:12px;" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-success" style="padding: 7px 8px 7px 8px;font-size:12px;">Accept Task</a>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal -->
                                        </td>
                                    </tr>
                                    <?php $number++; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="section-btn-25"><a href="<?php echo e(route('userearn')); ?>" class="btn btn-outline"><i class="fas fa-eye"></i><span>See all Task</span></a></div>
            </div>
        </div>
    </div>
</section><br><br>

<section class="section recent-part ">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-12 ">
                <div class="section-heading ">
                    <h2>Our Marketplace</h2>
                    <p>Buy and Sell anything on Miscochat Marketplace</p>
                </div>
            </div>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="product-card">
                    <div class="product-media">
                        <a class="product-image" href="#"><img src="../product/<?php echo e($prod->image); ?>" height="170px" alt="product"></a>

                    </div>
                    <div class="product-content">

                        <h6 class="product-name "><a href="#"><?php echo e($prod->name); ?></a></h6>
                        <h6 class="product-price"><span>₦<?php echo e(number_format($prod->price, 0, '.', ', ')); ?></span></h6>
                        <a href="<?php echo e(route('userproductdetails', $prod->slug)); ?>" class="btn btn-outline" style="padding:7px 8px 7px 8px;font-size:12px;"><i class="fas fa-eye"></i>View Product</a>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="section-btn-25"><a href="#" class="btn btn-outline"><i class="fas fa-eye"></i><span>Load More Product</span></a></div>
        </div>
    </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/dashboard.blade.php ENDPATH**/ ?>