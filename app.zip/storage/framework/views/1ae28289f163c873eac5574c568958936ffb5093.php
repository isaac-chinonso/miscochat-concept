
<?php $__env->startSection('title'); ?>
My Product || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->username); ?></span>
                                    <?php endif; ?>
                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="banner-btn" align="center">
                <a class="btn btn-inline" href="<?php echo e(url('/user/post-product')); ?>" style="padding: 7px 8px 7px 8px;font-size:12px;"><i class="fas fa-shopping-basket"></i><span>Post New Item</span></a><br>
                <p>Post New Item on Miscochat Marketplace</p>
            </div><br>
        </div>
    </div>
</div>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="account-card">
                    <h3 class="account-title">Product List on Miscochat Market </h3>
                    <div class="orderlist">
                        <div class="table-scroll table-responsive">
                            <table class="table table-stripped table-list">
                                <thead>
                                    <tr style="background-color: #5f04f6;">
                                        <th class="text-white" scope="col">#</th>
                                        <th class="text-white" scope="col">Product</th>
                                        <th class="text-white" scope="col">Name</th>
                                        <th class="text-white" scope="col">Price</th>
                                        <th class="text-white" scope="col">brand</th>
                                        <th class="text-white" scope="col">Phone</th>
                                        <th class="text-white" scope="col">location</th>
                                        <th class="text-white" scope="col">Description</th>
                                        <th class="text-white">Status</th>
                                        <th class="text-white">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="table-serial">
                                            <h6><?php echo e($number); ?></h6>
                                        </td>
                                        <td class="table-image"><img src="../product/<?php echo e($prod->image); ?>" alt="product"></td>
                                        <td class="table-name">
                                            <h6><?php echo e($prod->name); ?></h6>
                                        </td>
                                        <td class="table-price">
                                            <h6>₦<?php echo e(number_format($prod->price, 0, '.', ', ')); ?></h6>
                                        </td>
                                        <td class="table-brand">
                                            <h6><?php echo e($prod->brand); ?></h6>
                                        </td>
                                        <td class="table-quantity">
                                            <h6><?php echo e($prod->phone); ?></h6>
                                        </td>
                                        <td class="table-quantity">
                                            <h6><?php echo e($prod->location); ?></h6>
                                        </td>
                                        <td class="table-quantity">
                                            <h6><?php echo e($prod->description); ?></h6>
                                        </td>
                                        <td>
                                            <?php if($prod->status == 1): ?>
                                            <span class="badge bg-success">Active</span>
                                            <?php elseif($prod->status == 0): ?>
                                            <span class="badge bg-danger">Disabled</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="table-quantity">
                                            <a href="#" data-toggle="modal" data-target="#responsive-modal2<?php echo e($prod->id); ?>"><i class="fa fa-trash text-danger"></i></a>
                                            <!-- modal content -->
                                            <div id="responsive-modal2<?php echo e($prod->id); ?>" class="modal">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">Delete Product</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h4><strong>Confirm Deletion</strong></h4>
                                                            <p>Are you sure you want to Delete <?php echo e($prod->name); ?></p>
                                                            <img src="../product/<?php echo e($prod->image); ?>" width="150px" height="100px" alt="product">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" style="padding: 7px 8px 7px 8px;font-size:12px;" data-dismiss="modal">Close</button>
                                                            <a href="<?php echo e(route('deleteuserproduct',$prod->id)); ?>" class="btn btn-danger" style="padding: 7px 8px 7px 8px;font-size:12px;">Delete Product</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal -->
                                        </td>
                                    </tr>
                                    <?php $number++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/productlist.blade.php ENDPATH**/ ?>