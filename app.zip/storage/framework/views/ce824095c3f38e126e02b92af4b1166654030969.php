
<?php $__env->startSection('title'); ?>
Advert Task Proof || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->username); ?></span>
                                    <?php endif; ?>
                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="account-card">
                    <h3 class="account-title">Advert Task Perfomance Proof &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <a href="<?php echo e(route('useradverttaskprogress', $submitedtasks->order_id)); ?>">Go back</a></h3>
                    <div class="orderlist">
                        <h4>Screenshot 1</h4>
                        <img src="../../proof/<?php echo e($submitedtasks->image); ?>" width="300px" style="height:100%;"><br><hr>
                        <h4>Screenshot 2</h4>
                        <img src="../../proof/<?php echo e($submitedtasks->image1); ?>" width="300px" style="height:100%;"><br><hr>
                        <h4>Screenshot 3</h4>
                        <img src="../../proof/<?php echo e($submitedtasks->image2); ?>" width="300px" style="height:100%;"><br><hr>
                        <h4>Screenshot 4</h4>
                        <img src="../../proof/<?php echo e($submitedtasks->image3); ?>" width="300px" style="height:100%;">
                    </div>
                </div>
            </div>

        </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/adver_proof.blade.php ENDPATH**/ ?>