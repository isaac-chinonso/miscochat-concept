
<?php $__env->startSection('title'); ?>
Advert Task Progress || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="account-card">
                    <h3 class="account-title">
                        <?php if(date("H") < 12): ?> Good morning, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                            <?php elseif(date("H") >= 12 && date("H") < 16): ?> Good afternoon, <span class="text-danger"><?php echo e(Auth::user()->username); ?></span>
                                <?php elseif(date("H") >= 15 && date("H") < 24): ?> Good evening, <span class="text-danger"> <?php echo e(Auth::user()->username); ?></span>
                                    <?php endif; ?>
                    </h3>
                    <div class="my-wallet">
                        <p>Total Balance</p>
                        <h3>₦<?php echo e($walletbalance); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="inner-section wallet-part">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="account-card">
                    <h3 class="account-title">Lists of Users that accepted the task and performing </h3>
                    <div class="orderlist">
                        <div class="table-scroll table-responsive">
                            <table class="table table-stripped table-list">
                                <thead>
                                    <tr style="background-color: #5f04f6;">
                                        <th class="text-white" scope="col">#</th>
                                        <th class="text-white">Date</th>
                                        <th class="text-white" scope="col">Platform</th>
                                        <th class="text-white" scope="col">Users</th>
                                        <th class="text-white">Status</th>
                                        <th class="text-white">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $tasksprogress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskprog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($number); ?>

                                        </td>

                                        <td>
                                            <?php echo e($taskprog->created_at->format('d M Y ')); ?>

                                        </td>
                                        <td>
                                            <?php echo e($taskprog->order->platform); ?>

                                        </td>
                                        <td>
                                            <?php echo e($taskprog->user->username); ?>

                                        </td>
                                        <td>
                                            <?php if($taskprog->accept_status == 1): ?>
                                            <span class="badge bg-primary">Approved</span>
                                            <?php elseif($taskprog->accept_status == 0): ?>
                                            <span class="badge bg-danger">Waiting Submission</span>
                                            <?php elseif($taskprog->accept_status == 2): ?>
                                            <span class="badge bg-success">Completed</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($taskprog->accept_status == 0): ?>
                                            <span class="badge bg-danger">Waiting Submission</span>
                                            <?php elseif($taskprog->accept_status == 1): ?>
                                            <button class="btn btn-outline text-success" style="padding: 5px;font-size:10px;" data-toggle="modal" data-target="#responsive-modal2<?php echo e($taskprog->id); ?>">Approve Submission</button><br>
                                            <button class="btn btn-outline" style="padding: 5px;margin-top:5px;font-size:10px;"><a href="<?php echo e(route('useradverttaskproof', $taskprog->user_id)); ?>">performance Proof</a></button>
                                            <?php elseif($taskprog->accept_status == 2): ?>
                                            <button class="btn btn-outline" style="padding: 5px;margin-top:5px;font-size:10px;"><a href="<?php echo e(route('useradverttaskproof', $taskprog->user_id)); ?>">performance Proof</a></button>
                                            <?php endif; ?>
                                            <!-- modal content -->
                                            <div id="responsive-modal2<?php echo e($taskprog->id); ?>" class="modal">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">Approve User Submission</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h4><strong>Confirm User Submission as Completed</strong></h4>
                                                            <p>Are you sure you want to Confirm <strong><?php echo e($taskprog->user->username); ?></strong> Submission of <strong><?php echo e($taskprog->order->platform); ?></strong> Task as Completed</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form method="post" action="<?php echo e(route('userapprovetasksubmission',$taskprog->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="button" class="btn btn-default" style="padding: 7px 8px 7px 8px;font-size:12px;" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-success" style="padding: 7px 8px 7px 8px;font-size:12px;">Approve Submission</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal -->
                                        </td>
                                    </tr>
                                    <?php $number++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</section>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userapp1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/user/advert_progress.blade.php ENDPATH**/ ?>