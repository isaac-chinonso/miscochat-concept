
<?php $__env->startSection('title'); ?>
Orders || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="page-title">Advert Orders</h3>
                    <div class="d-inline-block align-items-center">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="ti ti-home"></i></a></li>
                                <li class="breadcrumb-item" aria-current="page">Advert</li>
                                <li class="breadcrumb-item active" aria-current="page">Orders</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="box">
                        <div class="box-body">
                            <div class="table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#ID</th>
                                            <th>User</th>
                                            <th>Platform</th>
                                            <th>Quantity</th>
                                            <th>Package</th>
                                            <th>Amount</th>
                                            <th>Gender</th>
                                            <th>Location</th>
                                            <th>Religion</th>
                                            <th>Image</th>
                                            <th>Caption</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h6><?php echo e($number); ?></h6>
                                            </td>

                                            <td><?php echo e($ord->user->username); ?></td>
                                            <td><?php echo e($ord->platform); ?></td>
                                            <td><?php echo e($ord->quantity); ?></td>
                                            <td><?php echo e($ord->package); ?></td>
                                            <td>₦<?php echo e(number_format($ord->amount, 0, '.', ', ')); ?></td>
                                            <td><?php echo e($ord->gender); ?></td>
                                            <td><?php echo e($ord->location); ?> </td>
                                            <td><?php echo e($ord->religion); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-25 h-60 w-60 rounded text-center b-1">
                                                        <img src="../advert/<?php echo e($ord->image); ?>" class="align-self-center" alt="">
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo e($ord->caption); ?></td>
                                            <td>
                                                <?php if($ord->status == 1): ?>
                                                <span class="badge bg-success">Allocated</span>
                                                <?php elseif($ord->status == 0): ?>
                                                <span class="badge bg-warning">Pending</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#allocate<?php echo e($ord->id); ?>">Allocate</button><br><br>
                                                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-default<?php echo e($ord->id); ?>"> Delete </button>
                                                <!-- modal Area -->
                                                <div class="modal fade" id="modal-default<?php echo e($ord->id); ?>">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Default Modal</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <h4><strong>Confirm Deletion</strong></h4>
                                                                <p>Are you sure you want to Delete <?php echo e($ord->name); ?></p>
                                                                <img src="../product/<?php echo e($ord->image); ?>" width="150px" height="100px" alt="product">
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?php echo e(route('deleteadminproduct',$ord->id)); ?>" class="btn btn-primary float-right">Delete Product</a>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>
                                                <!-- /.modal -->
                                                <!-- modal Area -->
                                                <div class="modal fade" id="allocate<?php echo e($ord->id); ?>">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Allocate Task to Users</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span></button>
                                                            </div>
                                                            <form method="post" action="<?php echo e(route('savetask',$ord->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">
                                                                    <h4><strong>Confirm Allocation</strong></h4>
                                                                    <p>Are you sure you want to Allocate Order to Random Users of <?php echo e($ord->quantity); ?> ?</p>
                                                                    <input type="hidden" name="order_id" value="<?php echo e($ord->id); ?>">
                                                                    <input type="hidden" name="buyer_id" value="<?php echo e($ord->user_id); ?>">
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                    <button class="btn btn-primary float-right" type="submit">Allocate</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>
                                                <!-- /.modal -->
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/admin/orders.blade.php ENDPATH**/ ?>