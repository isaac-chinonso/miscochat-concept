
<?php $__env->startSection('title'); ?>
Marketplace || Miscochat Concept
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main>
    <!-- breadcrumb area start -->
    <section class="breadcrumb__area breadcrumb-height include-bg p-relative" data-background="assets/img/breadcrumb/breadcurmb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="breadcrumb__content">
                        <h3 class="breadcrumb__title">Market Place</h3>
                        <div class="breadcrumb__list wow tpfadeUp" data-wow-duration=".9s">
                            <span><a href="#">Home</a></span>
                            <span class="dvdr"><i class="fa fa-angle-right"></i></span>
                            <span>Shop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb area end -->

    <!-- product-area-start -->
    <div class="tp-product-area pt-130 pb-130">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 wow tpfadeUp" data-wow-duration=".3s" data-wow-delay=".6s">
                    <div class="tpproduct text-center mb-50">
                        <div class="tpproduct__img">
                            <img class="w-100" src="product/<?php echo e($prod->image); ?>" alt="">
                            <div class="tp-product-icon">
                                <a href="<?php echo e(route('productdetails', $prod->slug)); ?>"><i class="fal fa-link"></i></a>
                            </div>
                        </div>
                        <div class="tpproduct__meta">
                            <span> <?php echo e($prod->category->name); ?> ( <?php echo e($prod->location); ?> )</span>
                            <h4 class="tp-product-title"><a href="#"><?php echo e($prod->name); ?> ( <?php echo e($prod->brand); ?> )</a></h4>
                            <span>₦<?php echo e(number_format($prod->price, 0, '.', ', ')); ?></span><br><br>
                            <button class="btn btn-outline-secondary btn-sm"><a href="<?php echo e(route('productdetails', $prod->slug)); ?>"> View Product</a></button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="container">
                    <div class="col-xl-12">
                        <div class="basic-pagination mt-30 text-center">
                            <nav>
                                <ul>
                                    <li>
                                        <a href="#"><?php echo e($products->links()); ?></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- product-area-end -->

    <!-- tp-social-area-start -->
    <div class="tp-social-area social-space-bottom fix">
        <div class="container-fluid p-0">
            <div class="row g-0">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <a href="#">
                        <div class="tp-social-item">
                            <span><i class="fab fa-facebook-f"></i> Facebook</span>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <a href="#">
                        <div class="tp-social-item tp-youtube">
                            <span><i class="fab fa-instagram"></i> instagram</span>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <a href="#">
                        <div class="tp-social-item tp-twitter">
                            <span><i class="fab fa-twitter"></i> twitter</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- tp-social-area-end -->
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\miscochat concept\resources\views/frontend/marketplace.blade.php ENDPATH**/ ?>